//
public class starter {
			
	public static void main(String args[]) {
		
	}

}