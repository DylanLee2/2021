import java.util.Scanner;
//
public class starter {
			
	public static void main(String args[]) {
		
		boolean on = true;
		while(on){
			System.out.println("\n\n\nBest to 3. Good luck.\n");
			Scanner sc = new Scanner(System.in);
			boolean game = true;
			int you = 0, opp = 0;
			
			while(you < 3 && opp < 3){
				System.out.print("Rock(1), Paper(2), Scissors(3): ");
				int inp = sc.nextInt();
				int opponent = (int)(Math.random()*3);
				String yourChoice = evaluate(inp);
				String oppChoice = evaluate(opponent);
				System.out.println("You: "+ yourChoice + ", Opponent: " + oppChoice + "\n");
				/*
				if(inp == 1 && opponent == 3)
					you++;
				else if(inp == 2 && opponent == 1)
					you++;
				else if(inp == 3 && opponent == 2)
					you++;
				else
					opponent++;
				*/
				you += (inp == 1 && opponent == 3) ? 1 : (inp == 2 && opponent == 1) ? 1 : (inp == 3 && opponent == 2) ? 1 : 0; 
				opp += (opponent == 1 && inp == 3) ? 1 : (opponent == 2&& inp == 1) ? 1 : (opponent == 3&& inp == 2) ? 1 : 0;
			}
			
			System.out.println("Score: you=" + you + ", opponent=" + opp);
			if(you > opp)
				System.out.println("You win!\n");
			else
				System.out.println("You lose... get good\n");
			
			System.out.print("Enter c to continue or anything else to quit: ");
			String cont = sc.next();
			on = cont.equals("c") ? true : false;
		}
		
	}
	
	public static String evaluate(int num){
		String eval = (num==1) ? "Rock" : (num==2) ? "Paper" : "Scissors"; 
		return eval;
	}

}